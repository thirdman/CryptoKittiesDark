# CryptoKittiesDark

A plugin for dark mode on CryptoKitties.co

## Credits

- icon: black cat by sara giacomini from the Noun Project
